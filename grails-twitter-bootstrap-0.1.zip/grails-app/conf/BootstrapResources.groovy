modules = {
    
    bootstrap {
        resource url:'/js/bootstrap-1.2.0.css', disposition: 'head'
    }

}